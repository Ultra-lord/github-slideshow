//Set amount of minutes here
const startingMinutes = 0.5;

//Get 60 seconds per minute by multiplying startingMinutes by 60
let time = startingMinutes * 60;

//set 'countdown' to constant variable for out function
const countdownEl = document.getElementById('countdown');

//Run our function every second to update timer every second.
setInterval(updateCountdown, 1000);


//function called every second
function updateCountdown() {
    //Use Math.floor to get the lowest number
    const minutes = Math.floor(time / 60);
    let seconds = time % 60;

    // add a 0 before the last second when there is less then 10 seconds left
    seconds = seconds < 10 ? '0' + seconds : seconds;
    //display minutes and seconds in the document.
    countdownEl.innerHTML = `${minutes}: ${seconds}`;
    //Every time the function completes remove one second
    time--;

    if (minutes==0 && seconds==0){
        clearInterval()
        
        countdownEl.innerHTML = "EXPIRED";
       
    }
}